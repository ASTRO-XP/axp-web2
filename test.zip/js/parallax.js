(function($) {

    var rellax = new Rellax('.rellax');

})(window.jQuery);